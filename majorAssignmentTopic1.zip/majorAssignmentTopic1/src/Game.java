public class Game {
    public static void main(String[] args) {
        TurnBasedRPG game = new TurnBasedRPG();
        game.setup();
        game.battle();
    }
}